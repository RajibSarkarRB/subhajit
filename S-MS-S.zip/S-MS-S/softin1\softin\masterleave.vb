﻿Public Class masterleave

End Class