﻿Public Class empinfo
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        With Me.OpenFileDialog1.Filter = "all files | *.*"
            If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
                txtphoto.Text = OpenFileDialog1.FileName
            End If
        End With
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        If txtnum.Text = "" Then
            MsgBox("enter the emp number ")
        ElseIf txtname.Text = "" Then
            MsgBox("enter emp name")
        ElseIf txtadd.Text = "" Then
            MsgBox("enter the address")
        ElseIf txtqual.Text = "" Then
            MsgBox("enter the qualification")
        ElseIf txtph.Text = "" Then
            MsgBox("enter phone number")
        ElseIf txtsal.Text = "" Then
            MsgBox("enter salary")
        ElseIf ComboBox1.Text = "" Then
            MsgBox("enter gender")
        ElseIf txtdes.Text = "" Then
            MsgBox("enter the designation")
        ElseIf txtwe.Text = "" Then
            MsgBox("enter the work experience")
        ElseIf txtphoto.Text = "" Then
            MsgBox("browse the photo")
        ElseIf Len(txtph.Text) < 10 Then
            MsgBox("Enter valid phone number")
        Else

            Dim years As Long

            years = DateDiff("yyyy", DateTimePicker1.Value, DateTimePicker2.Value)
            If years < 18 Then
                MsgBox("CHILD LABOUR!!!!?? :(")

            Else

                'lbl_years.Text = years.ToString & " Years"
                sql = "insert into tbl_empinfo(empno,name,address,dob,qualification,phone_number,gender,doj,designation,work_experience,photo)"
                sql = sql & "values('" & txtnum.Text & "','" & txtname.Text & " ','" & txtadd.Text & "',convert(date,'" & DateTimePicker1.Value & "',103),'" & txtqual.Text & "','" & txtph.Text & "','" & ComboBox1.Text & "',convert(date,'" & DateTimePicker2.Value & "',103),'" & txtdes.Text & "','" & txtwe.Text & "','" & txtphoto.Text & "' )"
                conn.Execute(sql)
                sql = "insert into tbl_bsal(empno,emp_sal)"
                sql = sql & "values('" & txtnum.Text & "','" & txtsal.Text & "')"
                conn.Execute(sql)
                MsgBox("Added successfully")
                loadgrid()
                clear()
            End If
        End If
        checkID()

    End Sub


    Private Sub empinfo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Button3.Enabled = False
        Button4.Enabled = False
        opendb()
        loadgrid()
        checkID()
    End Sub

    Private Sub txtphoto_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtphoto.TextChanged
        emppic1.ImageLocation = txtphoto.Text
    End Sub

    Sub loadgrid()
        sql = "select * from tbl_empinfo"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        DataGridView1.Rows.Clear()
        Dim i
        i = 0
        Do While Not rs.EOF
            DataGridView1.Rows.Add()
            DataGridView1.Item(0, i).Value = rs(0).Value
            DataGridView1.Item(1, i).Value = rs(1).Value
            DataGridView1.Item(2, i).Value = rs(2).Value
            DataGridView1.Item(3, i).Value = rs(3).Value
            DataGridView1.Item(4, i).Value = rs(4).Value
            DataGridView1.Item(5, i).Value = rs(5).Value
            DataGridView1.Item(6, i).Value = rs(6).Value
            DataGridView1.Item(7, i).Value = rs(7).Value
            DataGridView1.Item(8, i).Value = rs(8).Value
            DataGridView1.Item(9, i).Value = rs(9).Value

            DataGridView1.Item(10, i).Value = rs(10).Value
            sql = " select * from tbl_bsal where empno='" & DataGridView1.Item(0, i).Value & "'"
            If rss.State = 1 Then rss.Close()
            rss.Open(sql, conn)
            If rss.EOF = False Then
                DataGridView1.Item(11, i).Value = rss(1).Value
            End If
            rs.MoveNext()
            i = i + 1
        Loop
    End Sub
    Sub checkID()
        Dim j
        j = 100
        txtnum.Text = j
        sql = "select max(empno) from tbl_empinfo"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            j = rs(0).Value
            j = j + 1
            txtnum.Text = j
        End If

    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Button3.Enabled = True
        Button4.Enabled = True
        txtnum.Text = DataGridView1.CurrentRow.Cells(0).Value
        txtname.Text = DataGridView1.CurrentRow.Cells(1).Value
        txtadd.Text = DataGridView1.CurrentRow.Cells(2).Value
        DateTimePicker1.Value = DataGridView1.CurrentRow.Cells(3).Value
        txtqual.Text = DataGridView1.CurrentRow.Cells(4).Value
        txtph.Text = DataGridView1.CurrentRow.Cells(5).Value
        ComboBox1.Text = DataGridView1.CurrentRow.Cells(6).Value
        DateTimePicker2.Value = DataGridView1.CurrentRow.Cells(7).Value
        txtdes.Text = DataGridView1.CurrentRow.Cells(8).Value
        txtwe.Text = DataGridView1.CurrentRow.Cells(9).Value
        txtphoto.Text = DataGridView1.CurrentRow.Cells(10).Value
        txtsal.Text = DataGridView1.CurrentRow.Cells(11).Value
    End Sub

    Private Sub txtname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtname.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtph_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtph.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtph.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtsal_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsal.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtsal.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtwe_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtwe.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtwe.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtdes_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdes.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtdes.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        sql = "update tbl_empinfo set empno='" & txtnum.Text & "',name='" & txtname.Text & "',address='" & txtadd.Text & "',dob=convert(date,'" & DateTimePicker1.Value & "',103),qualification='" & txtqual.Text & "',phone_number='" & txtph.Text & "',gender='" & ComboBox1.Text & "',doj=convert(date,'" & DateTimePicker2.Value & "',103),designation='" & txtdes.Text & "',work_experience='" & txtwe.Text & "',photo='" & txtphoto.Text & "' where empno='" & DataGridView1.CurrentRow.Cells(0).Value & "'"
        conn.Execute(sql)
        MsgBox("record updated")
        loadgrid()
        clear()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        sql = "delete from tbl_empinfo where empno='" & DataGridView1.CurrentRow.Cells(0).Value & "'"
        conn.Execute(sql)
        If MsgBoxResult.No = MsgBox("do you want to permanently delete this record?", MsgBoxStyle.YesNo) Then Exit Sub
        MsgBox("record deleted")
        loadgrid()
        clear()
    End Sub
    Sub clear()
        'txtname.Text = ""
        'txtadd.Text = ""
        'txtqual.Text = ""
        'txtph.Text = ""
        'ComboBox1.SelectedIndex = -1
        'txtdes.Text = ""
        'txtwe.Text = ""
        'txtphoto.Text = ""
        'txtsal.Text = ""

        Dim frm As New empinfo
        frm.Show()
        frm.Close()
        frm = New empinfo
        frm.Show()
        Me.Close()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        clear()
    End Sub
End Class