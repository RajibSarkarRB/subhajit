﻿Public Class login
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opendb()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ComboBox1.Text = "" Then
            MsgBox("enter logintype")
        ElseIf txtname.Text = "" Then
            MsgBox("enter loginname")
        ElseIf txtpass.Text = "" Then
            MsgBox("enter loginpass")
        Else
            sql = " select * from tbl_login where logintype='" & ComboBox1.Text & "' and loginname='" & txtname.Text & "' and loginpass='" & txtpass.Text & "'"
            If rs.State = 1 Then rs.Close()
            rs.Open(sql, conn)
            If rs.EOF = False Then
                Me.Hide()
                menuform.Show()
            


                If ComboBox1.Text = "admin" Then
                    Me.Hide()
                    menuform.Show()
                    txtname.Text = ""
                    txtpass.Text = ""
                    ComboBox1.Text = ""

                ElseIf ComboBox1.Text = "subuser" Then
                    Me.Hide()
                    menuform.PAYROLLToolStripMenuItem.Visible = False

                    menuform.Show()
                    txtname.Text = ""
                    txtpass.Text = ""
                    ComboBox1.SelectedIndex = -1

                End If
            Else
                MsgBox("Login failed")
                clear()
                End If
            End If

    End Sub
    Sub clear()
        txtname.Text = ""
        txtpass.Text = ""
        ComboBox1.SelectedIndex = -1
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        clear()
    End Sub
End Class
