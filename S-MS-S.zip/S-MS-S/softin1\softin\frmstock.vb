﻿Public Class frmstock

    Sub loadgrid1()
        DataGridView1.Rows.Clear()

        sql = "select compno,goods,sum(quantity) from tbl_stock1 group by compno,goods"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        DataGridView1.Rows.Clear()
        Dim i
        i = 0
        Do While Not rs.EOF
            DataGridView1.Rows.Add()
            DataGridView1.Item(0, i).Value = rs(0).Value
            DataGridView1.Item(1, i).Value = rs(1).Value
            DataGridView1.Item(2, i).Value = rs(2).Value
            rs.MoveNext()
            i = i + 1

        Loop
    End Sub

    Private Sub frmstock_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opendb()
        loadgrid1()
    End Sub
End Class