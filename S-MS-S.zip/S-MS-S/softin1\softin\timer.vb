﻿Public Class timer

    Private Sub timer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If ProgressBar1.Value >= 10 Then
            Me.Hide()
            login.Show()
            Timer1.Enabled = False
            Exit Sub
        Else
            ProgressBar1.Value += 5
        End If
    End Sub

  
End Class