﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmtinreport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtplate = New System.Windows.Forms.TextBox
        Me.txtsolder = New System.Windows.Forms.TextBox
        Me.txtzinc = New System.Windows.Forms.TextBox
        Me.txtlids = New System.Windows.Forms.TextBox
        Me.txtshell = New System.Windows.Forms.TextBox
        Me.txtoil = New System.Windows.Forms.TextBox
        Me.txtcotton = New System.Windows.Forms.TextBox
        Me.txtscrape = New System.Windows.Forms.TextBox
        Me.txtgas = New System.Windows.Forms.TextBox
        Me.txt13 = New System.Windows.Forms.TextBox
        Me.txt14 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(138, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ELECTROLITIC TINPLATE"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "TIN SOLDER"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(19, 146)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(90, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "ZINC CHLORIDE"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 197)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "TIN LIDS"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(19, 239)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(122, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "CASHEW SHELL CAKE"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(311, 45)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(24, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "OIL"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(306, 89)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(94, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "COTTON WASTE"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(306, 133)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(71, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "TIN SCRAPE"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(306, 180)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "GAS CYLINDER"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(21, 29)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "TIN SIZE 13"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(21, 67)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(67, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "TIN SIZE 14"
        '
        'txtplate
        '
        Me.txtplate.Location = New System.Drawing.Point(175, 48)
        Me.txtplate.Name = "txtplate"
        Me.txtplate.Size = New System.Drawing.Size(100, 20)
        Me.txtplate.TabIndex = 11
        '
        'txtsolder
        '
        Me.txtsolder.Location = New System.Drawing.Point(175, 92)
        Me.txtsolder.Name = "txtsolder"
        Me.txtsolder.Size = New System.Drawing.Size(100, 20)
        Me.txtsolder.TabIndex = 12
        '
        'txtzinc
        '
        Me.txtzinc.Location = New System.Drawing.Point(175, 142)
        Me.txtzinc.Name = "txtzinc"
        Me.txtzinc.Size = New System.Drawing.Size(100, 20)
        Me.txtzinc.TabIndex = 13
        '
        'txtlids
        '
        Me.txtlids.Location = New System.Drawing.Point(175, 192)
        Me.txtlids.Name = "txtlids"
        Me.txtlids.Size = New System.Drawing.Size(100, 20)
        Me.txtlids.TabIndex = 14
        '
        'txtshell
        '
        Me.txtshell.Location = New System.Drawing.Point(175, 239)
        Me.txtshell.Name = "txtshell"
        Me.txtshell.Size = New System.Drawing.Size(100, 20)
        Me.txtshell.TabIndex = 15
        '
        'txtoil
        '
        Me.txtoil.Location = New System.Drawing.Point(417, 42)
        Me.txtoil.Name = "txtoil"
        Me.txtoil.Size = New System.Drawing.Size(100, 20)
        Me.txtoil.TabIndex = 16
        '
        'txtcotton
        '
        Me.txtcotton.Location = New System.Drawing.Point(417, 89)
        Me.txtcotton.Name = "txtcotton"
        Me.txtcotton.Size = New System.Drawing.Size(100, 20)
        Me.txtcotton.TabIndex = 17
        '
        'txtscrape
        '
        Me.txtscrape.Location = New System.Drawing.Point(417, 130)
        Me.txtscrape.Name = "txtscrape"
        Me.txtscrape.Size = New System.Drawing.Size(100, 20)
        Me.txtscrape.TabIndex = 18
        '
        'txtgas
        '
        Me.txtgas.Location = New System.Drawing.Point(417, 177)
        Me.txtgas.Name = "txtgas"
        Me.txtgas.Size = New System.Drawing.Size(100, 20)
        Me.txtgas.TabIndex = 19
        '
        'txt13
        '
        Me.txt13.Location = New System.Drawing.Point(132, 23)
        Me.txt13.Name = "txt13"
        Me.txt13.Size = New System.Drawing.Size(100, 20)
        Me.txt13.TabIndex = 20
        '
        'txt14
        '
        Me.txt14.Location = New System.Drawing.Point(132, 64)
        Me.txt14.Name = "txt14"
        Me.txt14.Size = New System.Drawing.Size(100, 20)
        Me.txt14.TabIndex = 21
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(341, 221)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(79, 31)
        Me.Button1.TabIndex = 22
        Me.Button1.Text = "OK"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"1", "2"})
        Me.ComboBox1.Location = New System.Drawing.Point(175, 12)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(100, 21)
        Me.ComboBox1.TabIndex = 23
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(12, 15)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(97, 26)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Select comp id for" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " electrolitic tin plate"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(332, 33)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(90, 46)
        Me.Button2.TabIndex = 25
        Me.Button2.Text = "ADD"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txt13)
        Me.GroupBox1.Controls.Add(Me.txt14)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 318)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(508, 113)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        '
        'frmtinreport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(555, 455)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtgas)
        Me.Controls.Add(Me.txtscrape)
        Me.Controls.Add(Me.txtcotton)
        Me.Controls.Add(Me.txtoil)
        Me.Controls.Add(Me.txtshell)
        Me.Controls.Add(Me.txtlids)
        Me.Controls.Add(Me.txtzinc)
        Me.Controls.Add(Me.txtsolder)
        Me.Controls.Add(Me.txtplate)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmtinreport"
        Me.Text = "frmtinreport"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtplate As System.Windows.Forms.TextBox
    Friend WithEvents txtsolder As System.Windows.Forms.TextBox
    Friend WithEvents txtzinc As System.Windows.Forms.TextBox
    Friend WithEvents txtlids As System.Windows.Forms.TextBox
    Friend WithEvents txtshell As System.Windows.Forms.TextBox
    Friend WithEvents txtoil As System.Windows.Forms.TextBox
    Friend WithEvents txtcotton As System.Windows.Forms.TextBox
    Friend WithEvents txtscrape As System.Windows.Forms.TextBox
    Friend WithEvents txtgas As System.Windows.Forms.TextBox
    Friend WithEvents txt13 As System.Windows.Forms.TextBox
    Friend WithEvents txt14 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
End Class
