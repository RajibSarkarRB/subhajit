﻿Imports System.Data
Imports System.Data.SqlClient
Module Module1
    Public conn As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public rss As New ADODB.Recordset
    Public sql As String
    Public name1 As String
    Public ID As String
    Public Date1 As Date
    Public gender As String
    Public blood As String
    Public nation, email, address1 As String
    Public phone, land As Long
    Public remaining As String
    Public Server As String
    Public Database As String
    Public User As String
    Public Password As String
    Public id1 As Integer
    Public vno As String
    Public ptc As Integer
    Public con As New SqlConnection("Server=SHARUN-PC;Database=softin;Trusted_Connection=false;user id=sa;password=q1w2e3r4/;")

    Public Function opendb()

        If conn.State = 1 Then conn.Close()
        conn.Open("Provider=SQLOLEDB.1;Persist Security Info=False;User ID=sa;password=q1w2e3r4/;Initial Catalog=softin;Data Source=SHARUN-PC")
        Return 0
    End Function
    Public Sub SetConnection(Optional ByVal Firstcomp As Boolean = False)
        Dim str As String
        str = "Data Source=SHARUN-PC;Initial Catalog=softin;User ID=sa;Password=q1w2e3r4/"
        Try
            If IsNothing(con) = False Then
                If con.State = ConnectionState.Closed Then
                    con.Close()
                End If
            End If
            con = New SqlConnection(str)
            con.Open()
        Catch ex As System.Exception
            MsgBox(ex.Message)
            MsgBox("Not Connecting to Database Server.Please check your network.")
        End Try
    End Sub
End Module
