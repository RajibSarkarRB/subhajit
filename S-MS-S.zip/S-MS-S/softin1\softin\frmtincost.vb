﻿Public Class frmtincost

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        sql = "select * from tbl_tinrate"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = True Then
            sql = "insert into tbl_tinrate(tin13,tin14)values('" & txtsize13.Text & "','" & txtsize14.Text & "')"
            conn.Execute(sql)
        Else
            sql = "update tbl_tinrate set tin13='" & txtsize13.Text & "',tin14='" & txtsize14.Text & "'"
            conn.Execute(sql)
            MsgBox("Cost of tin is added")
        End If
    End Sub

    Private Sub frmtincost_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opendb()
        sql = "select tin13,tin14 from tbl_tinrate"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)

        txtsize13.Text = rs(0).Value
        txtsize14.Text = rs(1).Value
    End Sub
    Private Sub txtsize13_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsize13.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtsize13.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtsize14_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsize14.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtsize14.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub
End Class