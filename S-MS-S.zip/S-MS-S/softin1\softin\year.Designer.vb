﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class year
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtjan = New System.Windows.Forms.TextBox
        Me.txtfeb = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtmarch = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtapril = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtmay = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtjune = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtjuly = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtaugust = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtsept = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtoct = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtnov = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtdec = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(68, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "JANUARY"
        '
        'txtjan
        '
        Me.txtjan.Location = New System.Drawing.Point(144, 53)
        Me.txtjan.Name = "txtjan"
        Me.txtjan.Size = New System.Drawing.Size(100, 20)
        Me.txtjan.TabIndex = 1
        '
        'txtfeb
        '
        Me.txtfeb.Location = New System.Drawing.Point(144, 97)
        Me.txtfeb.Name = "txtfeb"
        Me.txtfeb.Size = New System.Drawing.Size(100, 20)
        Me.txtfeb.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(60, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "FEBRUARY"
        '
        'txtmarch
        '
        Me.txtmarch.Location = New System.Drawing.Point(144, 138)
        Me.txtmarch.Name = "txtmarch"
        Me.txtmarch.Size = New System.Drawing.Size(100, 20)
        Me.txtmarch.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(79, 141)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "MARCH"
        '
        'txtapril
        '
        Me.txtapril.Location = New System.Drawing.Point(144, 186)
        Me.txtapril.Name = "txtapril"
        Me.txtapril.Size = New System.Drawing.Size(100, 20)
        Me.txtapril.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(87, 189)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(38, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "APRIL"
        '
        'txtmay
        '
        Me.txtmay.Location = New System.Drawing.Point(144, 234)
        Me.txtmay.Name = "txtmay"
        Me.txtmay.Size = New System.Drawing.Size(100, 20)
        Me.txtmay.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(95, 237)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "MAY"
        '
        'txtjune
        '
        Me.txtjune.Location = New System.Drawing.Point(144, 287)
        Me.txtjune.Name = "txtjune"
        Me.txtjune.Size = New System.Drawing.Size(100, 20)
        Me.txtjune.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(90, 290)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "JUNE"
        '
        'txtjuly
        '
        Me.txtjuly.Location = New System.Drawing.Point(468, 56)
        Me.txtjuly.Name = "txtjuly"
        Me.txtjuly.Size = New System.Drawing.Size(100, 20)
        Me.txtjuly.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(422, 63)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "JULY"
        '
        'txtaugust
        '
        Me.txtaugust.Location = New System.Drawing.Point(468, 97)
        Me.txtaugust.Name = "txtaugust"
        Me.txtaugust.Size = New System.Drawing.Size(100, 20)
        Me.txtaugust.TabIndex = 15
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(403, 100)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 13)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "AUGUST"
        '
        'txtsept
        '
        Me.txtsept.Location = New System.Drawing.Point(468, 138)
        Me.txtsept.Name = "txtsept"
        Me.txtsept.Size = New System.Drawing.Size(100, 20)
        Me.txtsept.TabIndex = 17
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(382, 141)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(73, 13)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "SEPTEMBER"
        '
        'txtoct
        '
        Me.txtoct.Location = New System.Drawing.Point(468, 186)
        Me.txtoct.Name = "txtoct"
        Me.txtoct.Size = New System.Drawing.Size(100, 20)
        Me.txtoct.TabIndex = 19
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(396, 189)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(59, 13)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "OCTOBER"
        '
        'txtnov
        '
        Me.txtnov.Location = New System.Drawing.Point(468, 234)
        Me.txtnov.Name = "txtnov"
        Me.txtnov.Size = New System.Drawing.Size(100, 20)
        Me.txtnov.TabIndex = 21
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(387, 237)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(68, 13)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "NOVEMBER"
        '
        'txtdec
        '
        Me.txtdec.Location = New System.Drawing.Point(468, 287)
        Me.txtdec.Name = "txtdec"
        Me.txtdec.Size = New System.Drawing.Size(100, 20)
        Me.txtdec.TabIndex = 23
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(388, 290)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(67, 13)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "DECEMBER"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(201, 344)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(67, 25)
        Me.Button1.TabIndex = 24
        Me.Button1.Text = "INSERT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'year
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(873, 424)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtdec)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtnov)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtoct)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtsept)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtaugust)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtjuly)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtjune)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtmay)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtapril)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtmarch)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtfeb)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtjan)
        Me.Controls.Add(Me.Label1)
        Me.Name = "year"
        Me.Text = "year"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtjan As System.Windows.Forms.TextBox
    Friend WithEvents txtfeb As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtmarch As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtapril As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtmay As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtjune As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtjuly As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtaugust As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtsept As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtoct As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtnov As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtdec As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
