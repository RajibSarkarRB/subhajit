﻿Public Class year

   
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        sql = "insert into tbl_year(jan,feb,mar,april,may,june,july,august,sept,oct,nov,dec)"
        sql = sql & "values('" & txtjan.Text & "','" & txtfeb.Text & "','" & txtmarch.Text & "','" & txtapril.Text & "','" & txtmay.Text & "','" & txtjune.Text & "','" & txtjuly.Text & "','" & txtaugust.Text & "','" & txtsept.Text & "','" & txtoct.Text & "','" & txtnov.Text & "','" & txtdec.Text & "')"
        conn.Execute(sql)
        MsgBox("Record inserted")

    End Sub

    Private Sub year_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opendb()

    End Sub
End Class