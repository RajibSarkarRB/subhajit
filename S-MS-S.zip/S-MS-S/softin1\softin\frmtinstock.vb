﻿Public Class frmtinstock

    Private Sub frmtinstock_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opendb()
        loadgrid1()
    End Sub
    Sub loadgrid1()
        DataGridView1.Rows.Clear()

        sql = "select tinsize13,tinsize14 from tbl_tinsize"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        DataGridView1.Rows.Clear()
        Dim i
        i = 0
        Do While Not rs.EOF
            DataGridView1.Rows.Add()
            DataGridView1.Item(0, i).Value = rs(0).Value
            DataGridView1.Item(1, i).Value = rs(1).Value
            rs.MoveNext()
            i = i + 1

        Loop
    End Sub
End Class