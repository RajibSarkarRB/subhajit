﻿Public Class reg
    Private Sub btnreg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreg.Click
        If ComboBox1.Text = "" Then
            MsgBox("enter logintype")
        ElseIf txtname.Text = "" Then
            MsgBox("enter loginname")
        ElseIf txtpass.Text = "" Then
            MsgBox("enter loginpass")
        Else
            sql = "select * from tbl_login where logintype='" & ComboBox1.Text & "' and loginname= '" & txtname.Text & "' "
            If rs.State = 1 Then rs.Close()
            rs.Open(sql, conn)
            If rs.EOF = False Then
                MsgBox("Record exist")
                clear()
            Else
                sql = "insert into tbl_login(logintype,loginname,loginpass)"
                sql = sql & "values('" & ComboBox1.Text & "','" & txtname.Text & " ','" & txtpass.Text & "')"
                conn.Execute(sql)
                MsgBox("registered successfully")
                clear()
                loadGrid()
            End If
        End If
    End Sub

    Private Sub reg_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnupdate.Enabled = False
        btndelete.Enabled = False
        opendb()
        loadGrid()
    End Sub


    Sub loadGrid()

        sql = "select * from tbl_login"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        DataGridView1.Rows.Clear()
        Dim i
        i = 0
        Do While Not rs.EOF
            DataGridView1.Rows.Add()
            DataGridView1.Item(0, i).Value = rs(1).Value
            DataGridView1.Item(1, i).Value = rs(2).Value
            DataGridView1.Item(2, i).Value = rs(3).Value
            rs.MoveNext()
            i = i + 1

        Loop
    End Sub
    Sub clear()
        ComboBox1.SelectedIndex = -1
        txtname.Text = ""
        txtpass.Text = ""
       
    End Sub

    Private Sub btnclr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclr.Click
        Dim frm As New reg
        frm.Show()
        frm.Close()
        frm = New reg
        frm.Show()
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        btnupdate.Enabled = True
        btndelete.Enabled = True
        btnreg.Enabled = False

        ComboBox1.Text = DataGridView1.CurrentRow.Cells(0).Value
        txtname.Text = DataGridView1.CurrentRow.Cells(1).Value
        txtpass.Text = DataGridView1.CurrentRow.Cells(2).Value
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        sql = "select * from tbl_login where loginname= '" & txtname.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            MsgBox("Record exist")
        Else
            sql = "update tbl_login set logintype='" & ComboBox1.Text & "',loginname='" & txtname.Text & "',loginpass='" & txtpass.Text & "' where loginname='" & DataGridView1.CurrentRow.Cells(1).Value & "'"
            conn.Execute(sql)
            MsgBox("record updated")
        End If

        loadGrid()
        clear()
    End Sub

    Private Sub btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndelete.Click
        sql = "delete from tbl_login where loginname='" & DataGridView1.CurrentRow.Cells(1).Value & "'"
        conn.Execute(sql)
        If MsgBoxResult.No = MsgBox("do you want to permanently delete this record?", MsgBoxStyle.YesNo) Then Exit Sub
        MsgBox("record deleted")
        loadGrid()
        clear()
    End Sub
End Class