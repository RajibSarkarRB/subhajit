﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class menuform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.PAYROLLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ACCOUNTCONFIGURATIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EMPLOYEEDETAILSToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SALARYToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PURCHASEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SALESToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.WORKDAYSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TINCOSTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BACKUPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.INVENTORYToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NEWSTOCKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.STOCKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RAWMATERIALSTOCKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TINSTOCKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TINREPORTSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TRANSACTIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CUSTOMERORDERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SALESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.INKARNATAKAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OUTKARNATAKAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HELPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EXITToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PAYROLLToolStripMenuItem, Me.INVENTORYToolStripMenuItem, Me.TRANSACTIONToolStripMenuItem, Me.HELPToolStripMenuItem, Me.EXITToolStripMenuItem1, Me.ToolStripMenuItem1, Me.ToolStripMenuItem2})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(682, 73)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'PAYROLLToolStripMenuItem
        '
        Me.PAYROLLToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ACCOUNTCONFIGURATIONToolStripMenuItem, Me.EMPLOYEEDETAILSToolStripMenuItem1, Me.SALARYToolStripMenuItem, Me.ToolStripMenuItem3, Me.WORKDAYSToolStripMenuItem, Me.TINCOSTToolStripMenuItem, Me.BACKUPToolStripMenuItem, Me.EXITToolStripMenuItem})
        Me.PAYROLLToolStripMenuItem.Image = Global.softin.My.Resources.Resources.payroll1
        Me.PAYROLLToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.PAYROLLToolStripMenuItem.Name = "PAYROLLToolStripMenuItem"
        Me.PAYROLLToolStripMenuItem.Size = New System.Drawing.Size(67, 69)
        Me.PAYROLLToolStripMenuItem.Text = "PAYROLL"
        Me.PAYROLLToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ACCOUNTCONFIGURATIONToolStripMenuItem
        '
        Me.ACCOUNTCONFIGURATIONToolStripMenuItem.Name = "ACCOUNTCONFIGURATIONToolStripMenuItem"
        Me.ACCOUNTCONFIGURATIONToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.ACCOUNTCONFIGURATIONToolStripMenuItem.Text = "ACCOUNT CONFIGURATION"
        '
        'EMPLOYEEDETAILSToolStripMenuItem1
        '
        Me.EMPLOYEEDETAILSToolStripMenuItem1.Name = "EMPLOYEEDETAILSToolStripMenuItem1"
        Me.EMPLOYEEDETAILSToolStripMenuItem1.Size = New System.Drawing.Size(222, 22)
        Me.EMPLOYEEDETAILSToolStripMenuItem1.Text = "EMPLOYEE DETAILS"
        '
        'SALARYToolStripMenuItem
        '
        Me.SALARYToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PURCHASEToolStripMenuItem, Me.SALESToolStripMenuItem1})
        Me.SALARYToolStripMenuItem.Name = "SALARYToolStripMenuItem"
        Me.SALARYToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.SALARYToolStripMenuItem.Text = "COMPANY NAME"
        '
        'PURCHASEToolStripMenuItem
        '
        Me.PURCHASEToolStripMenuItem.Name = "PURCHASEToolStripMenuItem"
        Me.PURCHASEToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.PURCHASEToolStripMenuItem.Text = "PURCHASE"
        '
        'SALESToolStripMenuItem1
        '
        Me.SALESToolStripMenuItem1.Name = "SALESToolStripMenuItem1"
        Me.SALESToolStripMenuItem1.Size = New System.Drawing.Size(131, 22)
        Me.SALESToolStripMenuItem1.Text = "SALES"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(222, 22)
        Me.ToolStripMenuItem3.Text = "PAY SALARY"
        '
        'WORKDAYSToolStripMenuItem
        '
        Me.WORKDAYSToolStripMenuItem.Name = "WORKDAYSToolStripMenuItem"
        Me.WORKDAYSToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.WORKDAYSToolStripMenuItem.Text = "WORK DAYS"
        '
        'TINCOSTToolStripMenuItem
        '
        Me.TINCOSTToolStripMenuItem.Name = "TINCOSTToolStripMenuItem"
        Me.TINCOSTToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.TINCOSTToolStripMenuItem.Text = "TIN COST"
        '
        'BACKUPToolStripMenuItem
        '
        Me.BACKUPToolStripMenuItem.Name = "BACKUPToolStripMenuItem"
        Me.BACKUPToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.BACKUPToolStripMenuItem.Text = "BACKUP"
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.EXITToolStripMenuItem.Text = "EXIT"
        '
        'INVENTORYToolStripMenuItem
        '
        Me.INVENTORYToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NEWSTOCKToolStripMenuItem, Me.STOCKToolStripMenuItem, Me.TINREPORTSToolStripMenuItem})
        Me.INVENTORYToolStripMenuItem.Image = Global.softin.My.Resources.Resources.purchase_icon
        Me.INVENTORYToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.INVENTORYToolStripMenuItem.Name = "INVENTORYToolStripMenuItem"
        Me.INVENTORYToolStripMenuItem.Size = New System.Drawing.Size(76, 69)
        Me.INVENTORYToolStripMenuItem.Text = "PURCHASE"
        Me.INVENTORYToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'NEWSTOCKToolStripMenuItem
        '
        Me.NEWSTOCKToolStripMenuItem.Name = "NEWSTOCKToolStripMenuItem"
        Me.NEWSTOCKToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.NEWSTOCKToolStripMenuItem.Text = "NEW STOCK"
        '
        'STOCKToolStripMenuItem
        '
        Me.STOCKToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RAWMATERIALSTOCKToolStripMenuItem, Me.TINSTOCKToolStripMenuItem})
        Me.STOCKToolStripMenuItem.Name = "STOCKToolStripMenuItem"
        Me.STOCKToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.STOCKToolStripMenuItem.Text = "STOCK"
        '
        'RAWMATERIALSTOCKToolStripMenuItem
        '
        Me.RAWMATERIALSTOCKToolStripMenuItem.Name = "RAWMATERIALSTOCKToolStripMenuItem"
        Me.RAWMATERIALSTOCKToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.RAWMATERIALSTOCKToolStripMenuItem.Text = "RAW MATERIAL STOCK"
        '
        'TINSTOCKToolStripMenuItem
        '
        Me.TINSTOCKToolStripMenuItem.Name = "TINSTOCKToolStripMenuItem"
        Me.TINSTOCKToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.TINSTOCKToolStripMenuItem.Text = "TIN STOCK"
        '
        'TINREPORTSToolStripMenuItem
        '
        Me.TINREPORTSToolStripMenuItem.Name = "TINREPORTSToolStripMenuItem"
        Me.TINREPORTSToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.TINREPORTSToolStripMenuItem.Text = "TIN REPORTS"
        '
        'TRANSACTIONToolStripMenuItem
        '
        Me.TRANSACTIONToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CUSTOMERORDERToolStripMenuItem, Me.SALESToolStripMenuItem})
        Me.TRANSACTIONToolStripMenuItem.Image = Global.softin.My.Resources.Resources.sale432
        Me.TRANSACTIONToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.TRANSACTIONToolStripMenuItem.Name = "TRANSACTIONToolStripMenuItem"
        Me.TRANSACTIONToolStripMenuItem.Size = New System.Drawing.Size(62, 69)
        Me.TRANSACTIONToolStripMenuItem.Text = "SALES"
        Me.TRANSACTIONToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'CUSTOMERORDERToolStripMenuItem
        '
        Me.CUSTOMERORDERToolStripMenuItem.Name = "CUSTOMERORDERToolStripMenuItem"
        Me.CUSTOMERORDERToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.CUSTOMERORDERToolStripMenuItem.Text = "CUSTOMER ORDER"
        '
        'SALESToolStripMenuItem
        '
        Me.SALESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.INKARNATAKAToolStripMenuItem, Me.OUTKARNATAKAToolStripMenuItem})
        Me.SALESToolStripMenuItem.Name = "SALESToolStripMenuItem"
        Me.SALESToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.SALESToolStripMenuItem.Text = "SALES REPORT"
        '
        'INKARNATAKAToolStripMenuItem
        '
        Me.INKARNATAKAToolStripMenuItem.Name = "INKARNATAKAToolStripMenuItem"
        Me.INKARNATAKAToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.INKARNATAKAToolStripMenuItem.Text = "IN KARNATAKA"
        '
        'OUTKARNATAKAToolStripMenuItem
        '
        Me.OUTKARNATAKAToolStripMenuItem.Name = "OUTKARNATAKAToolStripMenuItem"
        Me.OUTKARNATAKAToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.OUTKARNATAKAToolStripMenuItem.Text = "OUT KARNATAKA"
        '
        'HELPToolStripMenuItem
        '
        Me.HELPToolStripMenuItem.Image = Global.softin.My.Resources.Resources.help1
        Me.HELPToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.HELPToolStripMenuItem.Name = "HELPToolStripMenuItem"
        Me.HELPToolStripMenuItem.Size = New System.Drawing.Size(55, 69)
        Me.HELPToolStripMenuItem.Text = "HELP"
        Me.HELPToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'EXITToolStripMenuItem1
        '
        Me.EXITToolStripMenuItem1.Image = Global.softin.My.Resources.Resources._400_F_12954390_bU4iy9ISxe8dLMQGsL7CNEPzv53b3bJU
        Me.EXITToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.EXITToolStripMenuItem1.Name = "EXITToolStripMenuItem1"
        Me.EXITToolStripMenuItem1.Size = New System.Drawing.Size(68, 69)
        Me.EXITToolStripMenuItem1.Text = "LOG OUT"
        Me.EXITToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(12, 69)
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Image = Global.softin.My.Resources.Resources.exi
        Me.ToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(62, 69)
        Me.ToolStripMenuItem2.Text = "EXIT"
        Me.ToolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'menuform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.softin.My.Resources.Resources.softin3
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(682, 336)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "menuform"
        Me.Text = "menu"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents PAYROLLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INVENTORYToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NEWSTOCKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents STOCKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HELPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ACCOUNTCONFIGURATIONToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EMPLOYEEDETAILSToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SALARYToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BACKUPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PURCHASEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SALESToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TINREPORTSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WORKDAYSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TRANSACTIONToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CUSTOMERORDERToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SALESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TINCOSTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INKARNATAKAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OUTKARNATAKAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RAWMATERIALSTOCKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TINSTOCKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
End Class
