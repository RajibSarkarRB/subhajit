﻿Public Class frmsalesout

    Sub orderid()
        cmborder.Items.Clear()
        sql = "select order_id from tbl_custorder1 where status=0"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        Do While rs.EOF = False
            cmborder.Items.Add(rs(0).Value)
            rs.MoveNext()
        Loop
    End Sub
    Private Sub cmborder_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmborder.SelectedIndexChanged
        sql = " Select scomp_id from tbl_custorder1 where order_id='" & cmborder.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            txtnum.Text = rs(0).Value
        End If
        sql = " Select scomp_name from tbl_scomp where scomp_id='" & txtnum.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            txtname.Text = rs(0).Value
        End If
        sql = " Select tinsize_ordered from tbl_custorder1 where order_id='" & cmborder.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            txtsize.Text = rs(0).Value
        End If
        sql = " Select no_oftin_ordered from tbl_custorder1 where order_id='" & cmborder.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            txtnotin.Text = rs(0).Value
        End If
        Dim i As Double
        i = Val(txtvatnet.Text)
        i = Val(txtrate.Text) * Val(txtnotin.Text)
        txtvatnet.Text = i
    End Sub
    Sub checkID()
        Dim j
        j = 1
        txtid.Text = j
        sql = "select max(sales_id) from tbl_sales"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            j = rs(0).Value
            j = j + 1
            txtid.Text = j
        End If
    End Sub

    Private Sub frmsalesout_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opendb()
        checkID()
        orderid()
        loadid()
        btnadd.Enabled = False

    End Sub

    Sub loadid()
        Dim id
        sql = "select MAX(cast(SUBSTRING(invoice_out,7,len(invoice_out))+1 as int ))from tbl_sales "
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If IsDBNull(rs(0).Value) = True Then
            txtinv.Text = "OUTKAR1"
        Else
            If rs.EOF = False Then
                id = rs(0).Value
                id = "OUTKAR" & id
                txtinv.Text = id
            End If
        End If
    End Sub
    Private Sub txtsize_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtsize.TextChanged
        If txtsize.Text = 13 Then
            sql = " Select tin13 from tbl_tinrate "
            If rs.State = 1 Then rs.Close()
            rs.Open(sql, conn)
            If rs.EOF = False Then
                txtrate.Text = rs(0).Value
            End If
        Else
            sql = " Select tin14 from tbl_tinrate "
            If rs.State = 1 Then rs.Close()
            rs.Open(sql, conn)
            If rs.EOF = False Then
                txtrate.Text = rs(0).Value
            End If
        End If

    End Sub

    Private Sub txttax_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttax.TextChanged
        Dim i As Double
        i = Val(txt5tax.Text)
        i = Val(txtvatnet.Text) * Val(txttax.Text / 100)
        txt5tax.Text = i
        Dim a As Double
        a = Val(txttot.Text)
        a = Val(txt5tax.Text) + Val(txtvatnet.Text)
        txttot.Text = a
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Dim qty1 = 0, qty2 = 0
        sql = "select tinsize13 from tbl_tinsize "
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            qty1 = rs(0).Value
        End If
        sql = "select tinsize14 from tbl_tinsize "
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            qty2 = rs(0).Value
        End If
        If txtnotin.Text > qty1 Then
            MsgBox(" Tins of size13 is less in number")
            clear()
        ElseIf txtnotin.Text > qty2 Then

            MsgBox(" Tins of size14 is less in number")
            clear()
        ElseIf txttax.Text = "" Then
            MsgBox("Enter Tax")
        ElseIf TextBox1.Text = "" Then
            MsgBox("Enter vehicle number")
        Else
            id1 = txtid.Text
            vno = TextBox1.Text
            ptc = txtrate.Text
            sql = "insert into tbl_sales(sales_id,order_id,date,scomp_id,scomp_name,invoice_out,tin_size,no_of_items,vatnet_sale,tax,tax_amt,tot_amt)"
            sql = sql & "values('" & txtid.Text & "','" & cmborder.Text & "',convert(date,'" & DateTimePicker1.Value & "',103),'" & txtnum.Text & " ','" & txtname.Text & "','" & txtinv.Text & "','" & txtsize.Text & "','" & txtnotin.Text & "','" & txtvatnet.Text & "','" & txttax.Text & "','" & txt5tax.Text & "','" & txttot.Text & "')"
            conn.Execute(sql)
            sql = "delete from tbl_custorder1 where order_id ='" & cmborder.Text & "'"
            conn.Execute(sql)
            If txtsize.Text = 13 Then
                sql = "update tbl_tinsize set tinsize13=tinsize13 - '" & txtnotin.Text & "'"
                conn.Execute(sql)
                MsgBox("tins sold")
            Else
                sql = "update tbl_tinsize set tinsize14=tinsize14 - '" & txtnotin.Text & "'"
                conn.Execute(sql)
                MsgBox("tins sold")
            End If
        End If
    End Sub
    Sub clear()
        checkID()
        txtnum.Text = ""
        txtname.Text = ""
        txtinv.Text = ""
        txtnotin.Text = ""
        txtrate.Text = ""
        txtvatnet.Text = ""

        txt5tax.Text = ""
        txttot.Text = ""
        TextBox1.Text = ""
        txtid.Text = ""
        cmborder.SelectedIndex = -1
        btnadd.Enabled = False
    End Sub

    Private Sub btncl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncl.Click
        clear()
    End Sub

    Private Sub cmborder_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmborder.TextChanged
        btnadd.Enabled = True
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If vno = "" Then
            MsgBox("select record to print")

        Else

            Dim Sql = "select * from tbl_settings"
            Dim rs As New ADODB.Recordset
            rs.Open(Sql, conn)
            If rs.EOF = False Then
                Server = rs(0).Value
                Database = rs(1).Value
                User = rs(2).Value
                Password = rs(3).Value
            End If
            Dim rpt As New salesoutreport
            rpt.DataSourceConnections.Item(0).SetConnection(Server, Database, User, Password)
            rpt.DataSourceConnections.Item(0).SetLogon(User, Password)
            'rpt.RecordSelectionFormula = " {command.receiptNo}='" & txtrno.Text & "'"

            rpt.SetParameterValue("vno", vno)
            rpt.SetParameterValue("ptc", ptc)
            frmsalesoutreport.Text = "RECEIPT"
            frmsalesoutreport.CrystalReportViewer1.ReportSource = rpt
            frmsalesoutreport.CrystalReportViewer1.Refresh()
            frmsalesoutreport.ShowDialog()
        End If
    End Sub
End Class