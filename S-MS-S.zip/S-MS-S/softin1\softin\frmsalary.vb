﻿Public Class frmsalary
    Sub empno()
        ComboBox1.Items.Clear()
        sql = "select empno from tbl_empinfo"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        Do While rs.EOF = False
            ComboBox1.Items.Add(rs(0).Value)
            rs.MoveNext()
        Loop
    End Sub
    Sub year()
        ComboBox2.Items.Clear()
        sql = "select distinct(year) from tbl_yearset"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        Do While rs.EOF = False
            ComboBox2.Items.Add(rs(0).Value)
            rs.MoveNext()
        Loop
    End Sub
    Sub month()
        ComboBox3.Items.Clear()
        sql = "select month from tbl_yearset"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        Do While rs.EOF = False
            ComboBox3.Items.Add(rs(0).Value)
            rs.MoveNext()
        Loop
    End Sub

    Private Sub frmsalary_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtdayattended.Enabled = False
        opendb()
        empno()
        year()
        month()
        clear()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        sql = " Select Name from tbl_empinfo where empno='" & ComboBox1.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            txtname.Text = rs(0).Value
        End If
        sql = " Select emp_sal from tbl_bsal where empno='" & ComboBox1.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            txtsal.Text = rs(0).Value
        End If
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        txtdayattended.Enabled = True
        sql = " select work_day from tbl_yearset where  month='" & ComboBox3.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            txtworkday.Text = rs(0).Value
        End If
    End Sub


    Private Sub txtdayattended_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdayattended.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtdayattended.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (txtdayattended.Text > txtworkday.Text) Then
            txtdayattended.Text = ""
            MsgBox(" No of days attended must be less than no of working days")
        Else
            Dim bsal, workdays, attendance
            bsal = txtsal.Text
            workdays = txtworkday.Text
            attendance = txtdayattended.Text
            Dim netsal = (bsal * attendance) / workdays
            txtnetsal.Text = netsal
        End If
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        If ComboBox1.Text = "" Then
            MsgBox(" enter employee number")
        ElseIf ComboBox2.Text = "" Then
            MsgBox("Enter year")
        ElseIf ComboBox3.Text = "" Then
            MsgBox("Enter month")
        ElseIf txtdayattended.Text = "" Then
            MsgBox("Enter no of days attended")
        Else
            sql = "select * from tbl_sal where year='" & ComboBox2.Text & "' and month= '" & ComboBox3.Text & "'"
            If rs.State = 1 Then rs.Close()
            rs.Open(sql, conn)
            If rs.EOF = False Then
                MsgBox("Salary already paid")
            Else

                sql = "insert into tbl_sal(empno,year,month,work_day,day_attended,net_sal)"
                sql = sql & " values('" & ComboBox1.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" & txtworkday.Text & "','" & txtdayattended.Text & "','" & txtnetsal.Text & "' )"
                conn.Execute(sql)
                MsgBox("Added successfully")
            End If
        End If

        clear()
    End Sub
    Sub clear()
        ComboBox1.SelectedIndex = -1
        txtname.Text = ""
        txtsal.Text = ""
        ComboBox2.SelectedIndex = -1
        ComboBox3.SelectedIndex = -1
        txtworkday.Text = ""
        txtdayattended.Text = ""
        txtnetsal.Text = ""
    End Sub
    Private Sub btnclr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclr.Click
        clear()

    End Sub

  
End Class
