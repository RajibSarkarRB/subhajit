﻿Public Class customer_order
    Dim size

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If txtorderid.Text = "" Then
            MsgBox("enter number")
        ElseIf ComboBox2.Text = "" Then
            MsgBox("enter empno")
        ElseIf ComboBox1.Text = "" Then
            MsgBox("enter company name")
        ElseIf txtcompid.Text = "" Then
            MsgBox("enter company id")
        ElseIf txtqty.Text = "" Then
            MsgBox("enter quantity")
       

        Else
            tin_size()
            sql = "insert into tbl_custorder1(order_id,empno,scomp_id,order_date,delivery_date,tinsize_ordered,no_oftin_ordered,advance_paid,status)"
            sql = sql & "values('" & txtorderid.Text & "','" & ComboBox2.Text & "','" & txtcompid.Text & "',convert(date,'" & DateTimePicker1.Value & "',103),convert(date,'" & DateTimePicker2.Value & "',103),'" & size & "' ,'" & txtqty.Text & "',0,0)"
            conn.Execute(sql)
            MsgBox("Added successfully")
            loadgrid()
        End If
        clear()

    End Sub

    Sub tin_size()
        If RadioButton1.Checked = True Then
            size = 13
        Else
            size = 14
        End If
    End Sub
    Sub loadgrid()
        Dim cid
        sql = "select * from tbl_custorder1 where status=0"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        DataGridView1.Rows.Clear()
        Dim i
        i = 0
        Do While Not rs.EOF

            DataGridView1.Rows.Add()
            DataGridView1.Item(0, i).Value = rs(0).Value
            ' DataGridView1.c
            DataGridView1.Item(1, i).Value = rs(1).Value
            DataGridView1.Item(2, i).Value = rs(2).Value
            sql = "select * from tbl_scomp where scomp_id='" & rs(2).Value & "'"
            If rss.State = 1 Then rss.Close()
            rss.Open(sql, conn)
            If rss.EOF = False Then
                cid = rss(1).Value
            End If
            DataGridView1.Item(3, i).Value = cid
            DataGridView1.Item(4, i).Value = rs(3).Value
            DataGridView1.Item(5, i).Value = rs(4).Value
            DataGridView1.Item(6, i).Value = rs(5).Value
            DataGridView1.Item(7, i).Value = rs(6).Value

            rs.MoveNext()
            i = i + 1

        Loop
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Button2.Enabled = True
        Button3.Enabled = True
        txtorderid.Text = DataGridView1.CurrentRow.Cells(0).Value
        ComboBox2.Text = DataGridView1.CurrentRow.Cells(1).Value
        txtcompid.Text = DataGridView1.CurrentRow.Cells(2).Value
        ComboBox1.Text = DataGridView1.CurrentRow.Cells(3).Value
        DateTimePicker1.Value = DataGridView1.CurrentRow.Cells(4).Value
        DateTimePicker2.Value = DataGridView1.CurrentRow.Cells(5).Value
        If DataGridView1.CurrentRow.Cells(6).Value = 13 Then
            RadioButton1.Checked = True
        Else
            RadioButton2.Checked = True
        End If
        txtqty.Text = DataGridView1.CurrentRow.Cells(7).Value

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        tin_size()
        sql = "update tbl_custorder1 set order_id='" & txtorderid.Text & "',empno='" & ComboBox2.Text & "',scomp_id='" & txtcompid.Text & "',order_date=convert(date,'" & DateTimePicker1.Value & "',103),delivery_date=convert(date,'" & DateTimePicker2.Value & "',103),tinsize_ordered='" & size & "',no_oftin_ordered='" & txtqty.Text & "' where order_id='" & DataGridView1.CurrentRow.Cells(0).Value & "'"
        conn.Execute(sql)
        MsgBox("record updated")
        loadgrid()
        clear()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        sql = "delete from tbl_custorder1 where order_id ='" & DataGridView1.CurrentRow.Cells(0).Value & "'"
        conn.Execute(sql)
        MsgBox("record deleted")
        loadgrid()
        clear()
    End Sub
    Sub clear()
        checkID()
        ComboBox2.SelectedIndex = -1
        ComboBox1.SelectedIndex = -1
        txtcompid.Text = ""
        txtqty.Text = ""

    End Sub
    Sub checkID()
        Dim j
        
        sql = "select max(order_id) from tbl_custorder1"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If IsDBNull(rs(0).Value) = True Then
            j = 100
            txtorderid.Text = j
        Else
            j = rs(0).Value
            j = j + 1
            txtorderid.Text = j
        End If
    End Sub
    Sub empno()
        ComboBox2.Items.Clear()
        sql = "select empno from tbl_empinfo"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        Do While rs.EOF = False
            ComboBox2.Items.Add(rs(0).Value)
            rs.MoveNext()

        Loop


    End Sub
    Sub compname()
        ComboBox1.Items.Clear()
        sql = "select scomp_name from tbl_scomp"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        Do While rs.EOF = False
            ComboBox1.Items.Add(rs(0).Value)
            rs.MoveNext()
        Loop

    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        clear()
    End Sub

    
    Private Sub customer_order_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opendb()

        loadgrid()
        empno()
        compname()
        checkID()
        Button2.Enabled = False
        Button3.Enabled = False

    End Sub



    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        sql = " select scomp_id from tbl_scomp where scomp_name='" & ComboBox1.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            txtcompid.Text = rs(0).Value
        End If
    End Sub
    Private Sub txtqty_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtqty.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtqty.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub
End Class