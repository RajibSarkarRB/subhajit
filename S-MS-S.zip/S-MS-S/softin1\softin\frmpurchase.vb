﻿Public Class frmpurchase

    Private Sub frmpurchase_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opendb()
        'loadcheck()
        check()
        compname()
        reset()
    End Sub

    Sub compname()
        ComboBox1.Items.Clear()
        sql = "select pcomp_name from tbl_pcomp"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        Do While rs.EOF = False
            ComboBox1.Items.Add(rs(0).Value)
            rs.MoveNext()
        Loop
    End Sub

    Private Sub btninsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninsert.Click
        If txtno.Text = "" Then
            MsgBox("enter number")
        ElseIf txtnum.Text = "" Then
            MsgBox("enter cmpid")
        ElseIf txtinvoiceno.Text = "" Then
            MsgBox("enter invoice number")
        ElseIf txtraw.Text = "" Then
            MsgBox("enter discription of goods")
        ElseIf txtqty.Text = "" Then
            MsgBox("enter quantity")
        ElseIf txtamt.Text = "" Then
            MsgBox("enter amount")
        ElseIf txttax.Text = "" Then
            MsgBox("enter tax")
        ElseIf txttaxamt.Text = "" Then
            MsgBox("enter tax amount")
        ElseIf txttotamt.Text = "" Then
            MsgBox("enter total amount")
        Else
            sql = "insert into tbl_purchase(purchaseid,compno,date,invoice_no,invoice_date,disc_goods,quantity,amt,taxper,taxamt,total)"
            sql = sql & "values('" & txtno.Text & "','" & txtnum.Text & "',convert(date,'" & DateTimePicker1.Value & "',103),'" & txtinvoiceno.Text & " ',convert(date,'" & DateTimePicker2.Value & "',103),'" & txtraw.Text & "','" & txtqty.Text & "','" & txtamt.Text & "','" & txttax.Text & "','" & txttaxamt.Text & "','" & txttotamt.Text & "')"
            conn.Execute(sql)

            sql = "select * from tbl_stock1 where compno='" & txtnum.Text & "' and goods='" & txtraw.Text & "'"
            If rs.State = 1 Then rs.Close()
            rs.Open(sql, conn)
            If rs.EOF = False Then
                'If IsDBNull(rs(1).Value) = True Then
                sql = "update tbl_stock1 set quantity=quantity + '" & txtqty.Text & "' where compno='" & txtnum.Text & "' and goods='" & txtraw.Text & "'"
                conn.Execute(sql)
                MsgBox("Added successfully")
            Else
                sql = "insert into tbl_stock1(compno,goods,quantity)"
                sql = sql & "values('" & txtnum.Text & "','" & txtraw.Text & "','" & txtqty.Text & "')"
                conn.Execute(sql)
                MsgBox("Added successfully")
                ' MsgBox("record updated")

            End If
        End If
        loadcheck()
        reset()

    End Sub

    Sub loadgrid()
        Dim cid
        sql = "select * from tbl_purchase"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        DataGridView1.Rows.Clear()
        Dim i
        i = 0
        Do While Not rs.EOF
            DataGridView1.Rows.Add()
            DataGridView1.Item(0, i).Value = rs(0).Value
            DataGridView1.Item(1, i).Value = rs(2).Value
            DataGridView1.Item(2, i).Value = rs(1).Value
            DataGridView1.Item(3, i).Value = rs(3).Value
            DataGridView1.Item(4, i).Value = rs(4).Value
            DataGridView1.Item(5, i).Value = rs(5).Value
            DataGridView1.Item(6, i).Value = rs(6).Value
            DataGridView1.Item(7, i).Value = rs(7).Value
            DataGridView1.Item(8, i).Value = rs(8).Value
            DataGridView1.Item(9, i).Value = rs(9).Value
            rs.MoveNext()
            i = i + 1

        Loop
    End Sub

    Sub loadcheck()
        sql = "select * from tbl_purchase where date=convert(date,'" & DateTimePicker1.Value & "',103) and compno='" & txtnum.Text & "' "
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        DataGridView1.Rows.Clear()
        Dim i
        i = 0
        Do While Not rs.EOF
            DataGridView1.Rows.Add()
            DataGridView1.Item(0, i).Value = rs(0).Value
            DataGridView1.Item(1, i).Value = rs(2).Value
            DataGridView1.Item(2, i).Value = rs(1).Value
            DataGridView1.Item(3, i).Value = rs(3).Value
            DataGridView1.Item(4, i).Value = rs(4).Value
            DataGridView1.Item(5, i).Value = rs(5).Value
            DataGridView1.Item(6, i).Value = rs(6).Value
            DataGridView1.Item(7, i).Value = rs(7).Value
            DataGridView1.Item(8, i).Value = rs(8).Value
            DataGridView1.Item(9, i).Value = rs(9).Value
            DataGridView1.Item(10, i).Value = rs(10).Value
            rs.MoveNext()
            i = i + 1
        Loop
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        txtno.Text = DataGridView1.CurrentRow.Cells(0).Value
        DateTimePicker1.Value = DataGridView1.CurrentRow.Cells(1).Value
        txtnum.Text = DataGridView1.CurrentRow.Cells(2).Value
        txtinvoiceno.Text = DataGridView1.CurrentRow.Cells(3).Value
        DateTimePicker2.Value = DataGridView1.CurrentRow.Cells(4).Value
        txtraw.Text = DataGridView1.CurrentRow.Cells(5).Value
        txtqty.Text = DataGridView1.CurrentRow.Cells(6).Value
        txtamt.Text = DataGridView1.CurrentRow.Cells(7).Value
        txttax.Text = DataGridView1.CurrentRow.Cells(8).Value
        txttaxamt.Text = DataGridView1.CurrentRow.Cells(9).Value
        txttotamt.Text = DataGridView1.CurrentRow.Cells(10).Value
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        sql = "update tbl_purchase set purchaseid='" & txtno.Text & "',compno='" & txtnum.Text & "',date=convert(date,'" & DateTimePicker1.Value & "',103),invoice_no='" & txtinvoiceno.Text & "',invoice_date=convert(date,'" & DateTimePicker2.Value & "',103),disc_goods='" & txtraw.Text & "',quantity='" & txtqty.Text & "',amt='" & txtamt.Text & "',taxper='" & txttax.Text & "',taxamt='" & txttaxamt.Text & "',total='" & txttotamt.Text & "' where purchaseid='" & DataGridView1.CurrentRow.Cells(0).Value & "'"
        conn.Execute(sql)
        MsgBox("record updated")
        loadcheck()

    End Sub
    Sub check()
        Dim j
        j = 100
        txtno.Text = j
        sql = "select max(purchaseid) from tbl_purchase"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            j = rs(0).Value
            j = j + 1
            txtno.Text = j
        End If

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        sql = " Select * from tbl_pcomp where pcomp_name='" & ComboBox1.Text & "'"
        If rs.State = 1 Then rs.Close()
        rs.Open(sql, conn)
        If rs.EOF = False Then
            txtnum.Text = rs(1).Value
            txtraw.Text = rs(2).Value
        End If
    End Sub


    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        reset()
        check()
    End Sub

    Sub reset()
        ComboBox1.SelectedIndex = -1
        txtnum.Text = ""
        txtraw.Text = ""
        txtinvoiceno.Text = ""
        txtamt.Text = ""
        txttax.Text = ""
        txtqty.Text = ""
        txttaxamt.Text = ""
        txttotamt.Text = ""
    End Sub

   
    Private Sub txttax_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttax.TextChanged
        Dim i As Double
        i = Val(txttaxamt.Text)
        i = Val(txtamt.Text) * (Val(txttax.Text) / 100)
        txttaxamt.Text = i
        Dim a As Double
        a = Val(txttotamt.Text)
        a = Val(txtamt.Text) + Val(txttaxamt.Text)
        txttotamt.Text = a
    End Sub

    Private Sub txtinvoiceno_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtinvoiceno.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtinvoiceno.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtqty_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtqty.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtqty.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtamt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtamt.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtamt.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txttax_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttax.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txttax.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub


End Class
