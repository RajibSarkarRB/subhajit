﻿Imports System.Data.SqlClient
Public Class menuform

    Private Sub ACCOUNTCONFIGURATIONToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ACCOUNTCONFIGURATIONToolStripMenuItem.Click
        reg.MdiParent = Me
        reg.Show()

    End Sub

    Private Sub EMPLOYEEDETAILSToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EMPLOYEEDETAILSToolStripMenuItem1.Click
        empinfo.MdiParent = Me
        empinfo.Show()
    End Sub

    Private Sub PURCHASEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PURCHASEToolStripMenuItem.Click
        comp_purchase.MdiParent = Me
        comp_purchase.Show()

    End Sub

    Private Sub NEWSTOCKToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NEWSTOCKToolStripMenuItem.Click
        frmpurchase.MdiParent = Me
        frmpurchase.Show()
    End Sub

    Private Sub CUSTOMERORDERToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CUSTOMERORDERToolStripMenuItem.Click
        customer_order.MdiParent = Me
        customer_order.Show()
    End Sub

    Private Sub SALESToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SALESToolStripMenuItem1.Click
        comp_sales.MdiParent = Me
        comp_sales.Show()
    End Sub

    Private Sub ToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click
        frmsalary.MdiParent = Me
        frmsalary.Show()
    End Sub

    Private Sub TINREPORTSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TINREPORTSToolStripMenuItem.Click
        frmtinreport.MdiParent = Me
        frmtinreport.Show()
    End Sub

    Private Sub WORKDAYSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WORKDAYSToolStripMenuItem.Click
        frmyear.MdiParent = Me
        frmyear.Show()
    End Sub

    Private Sub TRANSACTIONToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TRANSACTIONToolStripMenuItem.Click

    End Sub

    Private Sub TINCOSTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TINCOSTToolStripMenuItem.Click
        frmtincost.MdiParent = Me
        frmtincost.Show()
    End Sub

    Private Sub INKARNATAKAToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles INKARNATAKAToolStripMenuItem.Click
        frmsales.MdiParent = Me
        frmsales.Show()
    End Sub

    Private Sub OUTKARNATAKAToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OUTKARNATAKAToolStripMenuItem.Click
        frmsalesout.MdiParent = Me
        frmsalesout.Show()
    End Sub

    Private Sub RAWMATERIALSTOCKToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RAWMATERIALSTOCKToolStripMenuItem.Click
        frmstock.MdiParent = Me
        frmstock.Show()
    End Sub

    Private Sub TINSTOCKToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TINSTOCKToolStripMenuItem.Click
        frmtinstock.MdiParent = Me
        frmtinstock.Show()
    End Sub

    Private Sub EXITToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXITToolStripMenuItem1.Click
        Me.Close()
        login.Show()
    End Sub

    Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem2.Click
        If MsgBoxResult.No = MsgBox("do you want to exit?", MsgBoxStyle.YesNo) Then Exit Sub
        Application.Exit()
    End Sub

    Private Sub menuform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BACKUPToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BACKUPToolStripMenuItem.Click
        DatabaseBackup.MdiParent = Me
        DatabaseBackup.Show()

    End Sub

    Private Sub EXITToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXITToolStripMenuItem.Click
        If MsgBoxResult.No = MsgBox("do you want to exit?", MsgBoxStyle.YesNo) Then Exit Sub
        Application.Exit()
    End Sub

    Private Sub INKARNATAKASALESBILLToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If vno = "" Then
            MsgBox("select record to print")

        Else

            Dim Sql = "select * from tbl_settings"
            Dim rs As New ADODB.Recordset
            rs.Open(Sql, conn)
            If rs.EOF = False Then
                Server = rs(0).Value
                Database = rs(1).Value
                User = rs(2).Value
                Password = rs(3).Value
            End If
            Dim rpt As New salesreport
            rpt.DataSourceConnections.Item(0).SetConnection(Server, Database, User, Password)
            rpt.DataSourceConnections.Item(0).SetLogon(User, Password)
            'rpt.RecordSelectionFormula = " {command.receiptNo}='" & txtrno.Text & "'"
            rpt.SetParameterValue("sid", id1)
            rpt.SetParameterValue("vno", vno)
            frmsalesreport.Text = "RECEIPT"
            frmsalesreport.CrystalReportViewer1.ReportSource = rpt
            frmsalesreport.CrystalReportViewer1.Refresh()
            frmsalesreport.ShowDialog()
        End If
    End Sub

    Private Sub OUTKARNATAKASALESBILLToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If vno = "" Then
            MsgBox("select record to print")

        Else

            Dim Sql = "select * from tbl_settings"
            Dim rs As New ADODB.Recordset
            rs.Open(Sql, conn)
            If rs.EOF = False Then
                Server = rs(0).Value
                Database = rs(1).Value
                User = rs(2).Value
                Password = rs(3).Value
            End If
            Dim rpt As New salesoutreport
            rpt.DataSourceConnections.Item(0).SetConnection(Server, Database, User, Password)
            rpt.DataSourceConnections.Item(0).SetLogon(User, Password)
            'rpt.RecordSelectionFormula = " {command.receiptNo}='" & txtrno.Text & "'"

            rpt.SetParameterValue("vno", vno)
            rpt.SetParameterValue("ptc", ptc)
            frmsalesoutreport.Text = "RECEIPT"
            frmsalesoutreport.CrystalReportViewer1.ReportSource = rpt
            frmsalesoutreport.CrystalReportViewer1.Refresh()
            frmsalesoutreport.ShowDialog()
        End If
    End Sub

    'Private Sub HELPToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HELPToolStripMenuItem.Click
    '    System.Diagnostics.Process.Start(Application.StartupPath.ToString & "\uploads\" & helpmenu.SelectedItems(0).SubItems(2).Text)
    'End Sub

    Private Sub HELPToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HELPToolStripMenuItem.Click
        System.Diagnostics.Process.Start("d:/softin/softin/softin/helpmenu.docx")
    End Sub
End Class